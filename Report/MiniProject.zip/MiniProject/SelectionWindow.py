from PySide6 import QtWidgets
import Panel

class SelectionWindow:
    '''This class constructs a window that holds a series of panels for selecting one of a collection of 
       objects. As an example, it can be used to choose a single maze for a selection of mazes.'''
    def __init__(self, informationDictionary, function):
        self.window = QtWidgets.QWidget()
        self.window.setWindowTitle("Maze Search")

        self.function = function
        self.panelList = []
        self.layout = QtWidgets.QHBoxLayout(self.window)
        self.setupLayout(informationDictionary)
        self.window.show()

    
    def setupLayout(self, informationDictionary):
        '''sets the layout of the window'''
        self.setupPanels(informationDictionary)
        self.window.setLayout(self.layout)
    
    def setupPanels(self, informationDictionary):
        '''A method that creates a panel for each key value pair within the information Dictionary, 
           the key is passed to the panel for it to use. it then connects the function property to 
           each of these panels and finally adds these panels to the layout.'''
        
        for key in informationDictionary:
            panel = Panel.Panel(key)
            panel.connectFunction(self.function)
            self.panelList.append(panel)
            self.layout.addWidget(panel.getButton())
        
    
if __name__ == '__main__':
    app = QtWidgets.QApplication()

    testDictionary = {"test1": 1, "test2": 2, "test3": 3}
    def testFunction(arg):
        print(arg)
    
    testWindow = SelectionWindow(testDictionary, testFunction)

    app.exec()