from PySide6 import QtWidgets
import sys
import SelectionWindow
import os
import json
import Maze
import MazeWindow
import importlib


class Main:
    '''The main class from which the application runs.'''
    def __init__(self):

        self.app = QtWidgets.QApplication(sys.argv)
        self.mazeDictionary = self.createMazeDictionaryFromJSonFiles()
        self.searchDictionary = self.createSearchDictionaryFromPythonFiles()
        self.mainWindow = SelectionWindow.SelectionWindow(self.mazeDictionary, self.selectMaze)
        self.maze = None
        self.pathTimeline = None

        self.main()
    
    def main(self):
        '''executes the application '''

        self.app.exec()
    
    def createMazeDictionaryFromJSonFiles(self):
        '''Creates a dictionary containing key value pairs where the key is the name of a maze,
            and the value is a json file containing the information about this maze.'''

        currentDirectory = os.getcwd()
        mazeFileDirectory = currentDirectory + '/MazeObjects'
        mazeFileList = os.listdir(mazeFileDirectory)

        mazeDictionary = {}

        for jsonFile in mazeFileList:
            fileLocation = mazeFileDirectory + '/' + jsonFile
            with open(fileLocation, 'r') as file:
                fileData = json.load(file)
                mazeDictionary[fileData["name"]] = fileLocation
        
        return mazeDictionary
    
    def createSearchDictionaryFromPythonFiles(self):
        '''Creates a dictionary containing key value pairs where the key is the name of a search algorithm,
           and the value is a reference to a module containing the implementation of the search algorithm'''
        
        currentDirectory = os.getcwd()
        searchFileDirectory = currentDirectory + '/SearchFiles'
        searchFileList = os.listdir(searchFileDirectory)

        searchDictionary = {}
        print(searchFileList)

        for file in searchFileList:
            if file[0] == '_':
                continue
            
            splitFile = file.split('.')

            if splitFile[1] == 'py':
                pythonModuleName = 'SearchFiles.' + splitFile[0]
                pythonModule = importlib.import_module(pythonModuleName)
                searchDictionary[pythonModule.name] = pythonModule

        return searchDictionary


    def selectMaze(self, maze):
        '''This function generates a maze and sets it to this class's maze,
           and then sets the main window to be the search selection window.'''
        
        self.maze = Maze.Maze(self.mazeDictionary[maze])

        self.mainWindow = SelectionWindow.SelectionWindow(self.searchDictionary, self.selectSearch)

    def selectSearch(self, search):
        '''This method generates a timeline of the paths that were traversed by the given search method,
           to find the path from the start to the end of the maze, it then calls the drawOnCanvas method'''

        self.pathTimeline = self.searchDictionary[search].search(self.maze)
        self.drawOnCanvas()
    
    def drawOnCanvas(self):
        '''This method generates a window which contains the drawing of the maze,
           and sets it to be the main window'''
        
        mazeWindow = MazeWindow.MazeWindow(self.maze, self.pathTimeline)
        self.mainWindow = mazeWindow

        
        


if __name__ == '__main__':
    app = Main()