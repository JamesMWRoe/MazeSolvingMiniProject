from PySide6 import QtWidgets

class Panel:
    '''This class represents a panel which can be clicked on to carry out the function connected with it.'''
    def __init__(self, text):
        self.text = text
        self.button = QtWidgets.QPushButton()
        self.button.setText(text)
        self.connectedFunction = self.empty
        self.button.pressed.connect(self.onPress)

    def empty(self):
        '''An empty function used as a placeholder before a function is connected to the panel.'''
        pass

    def connectFunction(self, function):
        '''connects a function to the panel, so that when the panel is clicked on the function is called'''
        self.connectedFunction = function
        
    def onPress(self):
        '''this function is called whenever the button contained within the panel is pressed. 
           It calls the function connected to this panel passing the function the panel's text property'''
        self.connectedFunction(self.text)

    def getButton(self):
        '''returns the QT pushbutton object contained within this panel.'''
        return self.button

if __name__ == '__main__':
    app = QtWidgets.QApplication()
    window = QtWidgets.QWidget()
    layout = QtWidgets.QHBoxLayout()
    def testFunction(text):
        print(text)


    testPanel = Panel('TEST')
    testPanel.connectFunction(testFunction)
    layout.addWidget(testPanel.getButton())
    window.setLayout(layout)

    window.show()
    app.exec()